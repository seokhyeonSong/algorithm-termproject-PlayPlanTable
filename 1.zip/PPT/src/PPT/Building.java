package PPT;

class Restaurant implements Comparable {
	String name = new String();
	String food = new String();
	int typ, spicy, sweet, oily, soup, hc;
	double x, y;
	int result;
	String type;
	public int compareTo(Object obj) {
		Restaurant other = (Restaurant) obj;
		if (result > other.result)
			return -1;
		else if (result < other.result)
			return 1;
		else
			return 0;
	}

}

class Sing {
	String name = new String();
	double x;
	double y;
}

class Bill {
	String name = new String();
	double x, y;
}

class Pc {
	String name = new String();
	double x, y;
}

class Cafe {
	String name = new String();
	double x, y;
}

class Station {
	String name = new String();
	double x, y;
}

class building {
	String name = new String();
	String type = new String();
	double x, y;
}

class Graph {
	private static int n;
	private static double maps[][];

	public Graph(int n) {
		this.n = n;
		maps = new double[n + 1][n + 1];
	}

	public void input(int i, int j, double w) {
		maps[i][j] = w;
		maps[j][i] = w;
	}

	public double[] dijkstra(int v) {
		double distance[] = new double[n + 1];
		boolean[] check = new boolean[n + 1];

		for (int i = 1; i < n + 1; i++) {
			distance[i] = Integer.MAX_VALUE;
		}

		distance[v] = 0;
		check[v] = true;

		for (int i = 1; i < n + 1; i++) {
			if (!check[i] && maps[v][i] != 0) {
				distance[i] = maps[v][i];
			}
		}

		for (int a = 0; a < n - 1; a++) {

			double min = 12345;
			int min_index = -1;

			for (int i = 1; i < n + 1; i++) {
				if (!check[i] && distance[i] < 12345) {
					if (distance[i] < min) {
						min = distance[i];
						min_index = i;
					}
				}
			}

			check[min_index] = true;
			for (int i = 1; i < n + 1; i++) {
				if (!check[i] && maps[min_index][i] != 0) {
					if (distance[i] > distance[min_index] + maps[min_index][i]) {
						distance[i] = distance[min_index] + maps[min_index][i];
					}
				}
			}

		}
		return distance;
	}

}
