package PPT;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class Food_Result extends JFrame {

	private JPanel contentPane;
	String msg = "";
	String order[];
	static String[] result = new String[2];
	static String food;
	static String building;
	int i = 0;
	static JLabel label_4 = new JLabel();
	static JLabel label_5 = new JLabel();

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DB test = new DB();
					Food_Attr3 frame = new Food_Attr3();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Food_Result() {
		setTitle("Play_Plan_Table");
		setIconImage(Toolkit.getDefaultToolkit()
				.getImage(Start.class.getResource("/ladybug.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		contentPane = new JPanel();
		contentPane.setBackground(Start.mint);
		contentPane.setForeground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		result = Start.getFood(i).split("/");
		food = result[0];
		building = result[1];
		JLabel label = new JLabel("");
		contentPane.add(label);
		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon("C:\\Users\\�ۼ���\\Desktop\\image\\image\\" + food + ".jpg"));
		label_2.setBounds(265, 137, 233, 234);
		contentPane.add(label_2);
		label_4.setHorizontalAlignment(SwingConstants.CENTER);
		label_4.setText(food);
		label_4.setForeground(Color.WHITE);
		label_4.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 35));
		label_4.setBounds(208, 397, 267, 58);
		contentPane.add(label_4);
		label_5.setHorizontalAlignment(SwingConstants.CENTER);

		label_5.setText(building);
		label_5.setForeground(Color.WHITE);
		label_5.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 25));
		label_5.setBounds(208, 452, 267, 50);
		contentPane.add(label_5);

		JLabel lblNewLabel_3 = new JLabel("  \uBD84");
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 19));
		lblNewLabel_3.setBounds(100, 12, 62, 18);
		contentPane.add(lblNewLabel_3);

		JLabel lblNewLabel_2 = new JLabel(Integer.toString(Play_Time.left));
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(83, 12, 62, 18);
		contentPane.add(lblNewLabel_2);

		JLabel label_1 = new JLabel("\uB0A8\uC740\uC2DC\uAC04");
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 19));
		label_1.setBounds(14, 12, 62, 18);
		contentPane.add(label_1);

		JButton btnNext = new JButton("");
		btnNext.setBorder(new EmptyBorder(5, 5, 5, 5));
		btnNext.setIcon(new ImageIcon(Food_Result.class.getResource("/next.png")));
		btnNext.setBounds(677, 431, 91, 79);
		contentPane.add(btnNext);

		JButton btnNewButton = new JButton("");
		btnNewButton.setIcon(new ImageIcon(Food_Result.class.getResource("/retry.jpg")));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				i++;
				result = Start.getFood(i).split("/");
				food = result[0];
				building = result[1];
				label_4.setText(food);
				label_5.setText(building);
				label_2.setIcon(new ImageIcon("C:\\Users\\�ۼ���\\Desktop\\image\\image\\" + food + ".jpg"));

			}
		});
		btnNewButton.setBounds(600, 452, 54, 54);
		contentPane.add(btnNewButton);

		JLabel label_3 = new JLabel("\uB2F9\uC2E0\uC774 \uD544\uC694\uD55C \uC74C\uC2DD\uC740");
		label_3.setForeground(Color.WHITE);
		label_3.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 40));
		label_3.setBounds(208, 54, 322, 94);
		contentPane.add(label_3);

		JLabel label_6 = new JLabel("\uC785\uB2C8\uB2E4");
		label_6.setForeground(Color.WHITE);
		label_6.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 40));
		label_6.setBounds(479, 428, 140, 65);
		contentPane.add(label_6);

		JLabel label_7 = new JLabel("");
		label_7.setBounds(218, 137, 62, 246);
		contentPane.add(label_7);

		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object obj = e.getSource();
				if ((JButton) obj == btnNext) {
					msg = Order.getMsg();
					order = msg.split("/");
					if (order[0].equals(order[1])) {
						Result last = new Result();
						dispose();
						last.setVisible(true);
					} else {
						if (order[0].equals("1")) {
							if (order[3].equals("PC")) {
								PC_Time time = new PC_Time();
								Order.msg = "2/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[3].equals("Sing")) {
								Sing_Time time = new Sing_Time();
								Order.msg = "2/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[3].equals("Pocket")) {
								Pocket_Time time = new Pocket_Time();
								Order.msg = "2/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[3].equals("Meal")) {
								Food_Attr1 time = new Food_Attr1();
								Order.msg = "2/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[3].equals("Cafe")) {
								Cafe_Time time = new Cafe_Time();
								Order.msg = "2/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							}
						} else if (order[0].equals("2")) {
							if (order[4].equals("PC")) {
								PC_Time time = new PC_Time();
								Order.msg = "3/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[4].equals("Sing")) {
								Sing_Time time = new Sing_Time();
								Order.msg = "3/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[4].equals("Pocket")) {
								Pocket_Time time = new Pocket_Time();
								Order.msg = "3/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[4].equals("Meal")) {
								Food_Attr1 time = new Food_Attr1();
								Order.msg = "3/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[4].equals("Cafe")) {
								Cafe_Time time = new Cafe_Time();
								Order.msg = "3/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							}
						} else if (order[0].equals("3")) {
							if (order[5].equals("PC")) {
								PC_Time time = new PC_Time();
								Order.msg = "4/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[5].equals("Sing")) {
								Sing_Time time = new Sing_Time();
								Order.msg = "4/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[5].equals("Pocket")) {
								Pocket_Time time = new Pocket_Time();
								Order.msg = "4/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[5].equals("Meal")) {
								Food_Attr1 time = new Food_Attr1();
								Order.msg = "4/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[5].equals("Cafe")) {
								Cafe_Time time = new Cafe_Time();
								Order.msg = "4/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							}
						} else if (order[0].equals("4")) {
							if (order[6].equals("PC")) {
								PC_Time time = new PC_Time();
								Order.msg = "5/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[6].equals("Sing")) {
								Sing_Time time = new Sing_Time();
								Order.msg = "5/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[6].equals("Pocket")) {
								Pocket_Time time = new Pocket_Time();
								Order.msg = "5/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[6].equals("Meal")) {
								Food_Attr1 time = new Food_Attr1();
								Order.msg = "5/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[6].equals("Cafe")) {
								Cafe_Time time = new Cafe_Time();
								Order.msg = "5/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							}

						}
					}
				}
			}
		});

		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object obj = e.getSource();
				Play_Time.left = Play_Time.left - 30;
			}
		});
	}
}
