package PPT;

import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;

public class DB {
	public static String database;
	static Restaurant[] restaurant = new Restaurant[191];

	public static void main(String[] args) throws UnsupportedEncodingException {
		Connection con = null;
		int bnum = 1;
		building[] buildinfo = new building[141];
		for (int i = 0; i < 131; i++)
			buildinfo[i] = new building();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/ppt";
			String user = "root", passwd = "12345";
			con = DriverManager.getConnection(url, user, passwd);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		Statement stmt = null;
		ResultSet rs = null;

		try {
			stmt = (Statement) con.createStatement();
			String sql = "select * from restaurant;";
			int i = 0;
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				restaurant[i] = new Restaurant();
				String name = rs.getString(1);
				byte[] b = name.getBytes("EUC-KR");
				name = new String(b, "euckr");
				restaurant[i].name = name;
				String food = rs.getString(2);
				byte[] c = food.getBytes("EUC-KR");
				food = new String(c, "euckr");
				restaurant[i].food = food;
				int type = rs.getInt(3);
				int spicy = rs.getInt(4);
				restaurant[i].spicy = spicy;
				int sweet = rs.getInt(5);
				restaurant[i].sweet = sweet;
				int oily = rs.getInt(6);
				restaurant[i].oily = oily;
				int soup = rs.getInt(7);
				restaurant[i].soup = soup;
				int hc = rs.getInt(8);
				restaurant[i].hc = hc;
				Double x = rs.getDouble(9);
				restaurant[i].type = "meal";
				restaurant[i].x = x;
				Double y = rs.getDouble(10);
				restaurant[i].y = y;
				i++;
			}

			stmt = (Statement) con.createStatement();
			sql = "select distinct name, x, y from restaurant;";
			i = 0;
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				String name = rs.getString(1);
				byte[] b = name.getBytes("EUC-KR");
				name = new String(b, "euckr");
				buildinfo[bnum].name = name;
				Double x = rs.getDouble(2);
				buildinfo[bnum].x = x;
				Double y = rs.getDouble(3);
				buildinfo[bnum].y = y;
				bnum++;
			}
			stmt = (Statement) con.createStatement();
			sql = "select * from sing;";
			Sing[] sing = new Sing[100];
			i = 0;

			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				sing[i] = new Sing();
				String name = rs.getString(1);
				byte[] b = name.getBytes("EUC-KR");
				name = new String(b, "euckr");
				sing[i].name = name;
				buildinfo[bnum].name = name;
				buildinfo[bnum].type = "karaoke";
				Double x = rs.getDouble(2);
				sing[i].x = x;
				buildinfo[bnum].x = x;
				Double y = rs.getDouble(3);
				sing[i].y = y;
				buildinfo[bnum].y = y;
				i++;
				bnum++;
			}

			stmt = (Statement) con.createStatement();
			sql = "select * from bill;";
			Bill[] bill = new Bill[100];
			i = 0;
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				bill[i] = new Bill();
				String name = rs.getString(1);
				byte[] b = name.getBytes("EUC-KR");
				name = new String(b, "euckr");
				bill[i].name = name;
				buildinfo[bnum].name = name;
				buildinfo[bnum].type = "bill";
				Double x = rs.getDouble(2);
				bill[i].x = x;
				buildinfo[bnum].x = x;
				Double y = rs.getDouble(3);
				bill[i].y = y;
				buildinfo[bnum].y = y;
				i++;
				bnum++;
			}

			stmt = (Statement) con.createStatement();
			sql = "select * from cafe;";
			Cafe[] cafe = new Cafe[100];
			i = 0;
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				cafe[i] = new Cafe();
				String name = rs.getString(1);
				byte[] b = name.getBytes("EUC-KR");
				name = new String(b, "euckr");
				cafe[i].name = name;
				buildinfo[bnum].name = name;
				buildinfo[bnum].type = "cafe";
				Double x = rs.getDouble(2);
				cafe[i].x = x;
				buildinfo[bnum].x = x;
				Double y = rs.getDouble(3);
				cafe[i].y = y;
				buildinfo[bnum].y = y;
				i++;
				bnum++;
			}

			stmt = (Statement) con.createStatement();
			sql = "select * from pc;";
			Pc[] pc = new Pc[100];
			i = 0;
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				pc[i] = new Pc();
				String name = rs.getString(1);
				byte[] b = name.getBytes("EUC-KR");
				name = new String(b, "euckr");
				pc[i].name = name;
				buildinfo[bnum].name = name;
				buildinfo[bnum].type = "pc";
				Double x = rs.getDouble(2);
				pc[i].x = x;
				buildinfo[bnum].x = x;
				Double y = rs.getDouble(3);
				pc[i].y = y;
				buildinfo[bnum].y = y;
				i++;
				bnum++;
			}

			stmt = (Statement) con.createStatement();
			sql = "select * from station;";
			Station[] station = new Station[100];
			i = 0;
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				station[i] = new Station();
				String name = rs.getString(1);
				byte[] b = name.getBytes("EUC-KR");
				name = new String(b, "euckr");
				station[i].name = name;
				buildinfo[bnum].name = name;
				buildinfo[bnum].type = "station";
				Double x = rs.getDouble(2);
				station[i].x = x;
				buildinfo[bnum].x = x;
				Double y = rs.getDouble(3);
				station[i].y = y;
				buildinfo[bnum].y = y;
				i++;
				bnum++;
			}

		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		try {
			if (stmt != null && !stmt.isClosed())
				stmt.close();
			if (rs != null && !rs.isClosed())
				rs.close();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		try {
			if (con != null && !con.isClosed())
				con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}