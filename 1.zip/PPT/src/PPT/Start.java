package PPT;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.io.File;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.awt.Color;
import sun.audio.*;
import com.sun.media.*;
import sun.audio.AudioData;
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;
import sun.audio.ContinuousAudioDataStream;
import java.awt.Toolkit;

public class Start extends JFrame {

	static InputStream IN;
	static AudioStream BGM;
	static AudioPlayer MGP = AudioPlayer.player;
	static building[] buildinfo = new building[141];
	{
		for (int i = 0; i < 131; i++) {
			buildinfo[i] = new building();
		}
	}
	private JPanel contentPane;
	static Color mint = new Color(42, 193, 188);
	public static String database;
	static int data_num = 0;
	static Graph g = new Graph(129);
	static Restaurant[] restaurant = new Restaurant[191];

	static String getFood(int p) {
		int[] input = new int[] { Food_Attr1.LCS.get(4), Food_Attr1.LCS.get(0), Food_Attr1.LCS.get(1),
				Food_Attr1.LCS.get(5), Food_Attr1.LCS.get(3), Food_Attr1.LCS.get(2) };
		int j = 1;
		int[][] LCS = new int[6][6];
		int i;
		for (i = 0; i < 6; i++)
			LCS[0][i] = 0;
		for (i = 1; i < 6; i++)
			LCS[i][0] = 0;
		for (int k = 0; k < data_num; k++) {
			if (input[0] == restaurant[k].typ) {
				for (i = 1; i <= 5; i++) {

					if (input[i] == restaurant[k].spicy)
						LCS[i][j] = LCS[i - 1][j - 1] + 1;
					else
						LCS[i][j] = Math.max(LCS[i][j - 1], LCS[i - 1][j]);
					j++;
					if (input[i] == restaurant[k].sweet)
						LCS[i][j] = LCS[i - 1][j - 1] + 1;
					else
						LCS[i][j] = Math.max(LCS[i][j - 1], LCS[i - 1][j]);
					j++;
					if (input[i] == restaurant[k].oily)
						LCS[i][j] = LCS[i - 1][j - 1] + 1;
					else
						LCS[i][j] = Math.max(LCS[i][j - 1], LCS[i - 1][j]);
					j++;
					if (input[i] == restaurant[k].soup)
						LCS[i][j] = LCS[i - 1][j - 1] + 1;
					else
						LCS[i][j] = Math.max(LCS[i][j - 1], LCS[i - 1][j]);
					j++;
					if (input[i] == restaurant[k].hc)
						LCS[i][j] = LCS[i - 1][j - 1] + 1;
					else
						LCS[i][j] = Math.max(LCS[i][j - 1], LCS[i - 1][j]);

					j = 1;

				}

				restaurant[k].result = LCS[5][5];
			}
		}
		Arrays.sort(restaurant);
		return restaurant[p].food + "/" + restaurant[p].name;
	}

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Start frame = new Start();
					Connection con = null;
					int bnum = 1;
					double[] distance = new double[130];
					try {
						Class.forName("com.mysql.jdbc.Driver");
						String url = "jdbc:mysql://localhost:3306/ppt";
						String user = "root", passwd = "12345";
						con = DriverManager.getConnection(url, user, passwd);
					} catch (ClassNotFoundException e) {
						e.printStackTrace();
					} catch (SQLException e) {
						e.printStackTrace();
					}

					Statement stmt = null;
					ResultSet rs = null;

					try {
						stmt = (Statement) con.createStatement();
						String sql = "select * from restaurant;";
						int i = 0;
						rs = stmt.executeQuery(sql);
						while (rs.next()) {
							restaurant[i] = new Restaurant();
							String name = rs.getString(1);
							byte[] b = name.getBytes("EUC-KR");
							name = new String(b, "euckr");
							restaurant[i].name = name;
							String food = rs.getString(2);
							byte[] c = food.getBytes("EUC-KR");
							food = new String(c, "euckr");
							restaurant[i].food = food;
							int type = rs.getInt(3);
							restaurant[i].typ = type;
							int spicy = rs.getInt(4);
							restaurant[i].spicy = spicy;
							int sweet = rs.getInt(5);
							restaurant[i].sweet = sweet;
							int oily = rs.getInt(6);
							restaurant[i].oily = oily;
							int soup = rs.getInt(7);
							restaurant[i].soup = soup;
							int hc = rs.getInt(8);
							restaurant[i].hc = hc;
							Double x = rs.getDouble(9);
							restaurant[i].x = x * 100000;
							Double y = rs.getDouble(10);
							restaurant[i].y = y * 100000;
							i++;
							data_num++;
						}

						stmt = (Statement) con.createStatement();
						sql = "select distinct name, x, y from restaurant;";
						i = 0;
						rs = stmt.executeQuery(sql);
						while (rs.next()) {
							String name = rs.getString(1);
							byte[] b = name.getBytes("EUC-KR");
							name = new String(b, "euckr");
							buildinfo[bnum].name = name;
							buildinfo[bnum].type = "Meal";
							Double x = rs.getDouble(2);
							buildinfo[bnum].x = x * 100000;
							Double y = rs.getDouble(3);
							buildinfo[bnum].y = y * 100000;
							bnum++;
						}

						stmt = (Statement) con.createStatement();
						sql = "select * from sing;";
						Sing[] sing = new Sing[100];
						i = 0;

						rs = stmt.executeQuery(sql);
						while (rs.next()) {
							sing[i] = new Sing();
							String name = rs.getString(1);
							byte[] b = name.getBytes("EUC-KR");
							name = new String(b, "euckr");
							sing[i].name = name;
							buildinfo[bnum].name = name;
							buildinfo[bnum].type = "Sing";
							Double x = rs.getDouble(2);
							sing[i].x = x;
							buildinfo[bnum].x = x * 100000;
							Double y = rs.getDouble(3);
							sing[i].y = y;
							buildinfo[bnum].y = y * 100000;
							i++;
							bnum++;
						}

						stmt = (Statement) con.createStatement();
						sql = "select * from bill;";
						Bill[] bill = new Bill[100];
						i = 0;
						rs = stmt.executeQuery(sql);
						while (rs.next()) {
							bill[i] = new Bill();
							String name = rs.getString(1);
							byte[] b = name.getBytes("EUC-KR");
							name = new String(b, "euckr");
							bill[i].name = name;
							buildinfo[bnum].name = name;
							buildinfo[bnum].type = "Pocket";
							Double x = rs.getDouble(2);
							bill[i].x = x;
							buildinfo[bnum].x = x * 100000;
							Double y = rs.getDouble(3);
							bill[i].y = y;
							buildinfo[bnum].y = y * 100000;
							i++;
							bnum++;
						}

						stmt = (Statement) con.createStatement();
						sql = "select * from cafe;";
						Cafe[] cafe = new Cafe[100];
						i = 0;
						rs = stmt.executeQuery(sql);
						while (rs.next()) {
							cafe[i] = new Cafe();
							String name = rs.getString(1);
							byte[] b = name.getBytes("EUC-KR");
							name = new String(b, "euckr");
							cafe[i].name = name;
							buildinfo[bnum].name = name;
							buildinfo[bnum].type = "Cafe";
							Double x = rs.getDouble(2);
							cafe[i].x = x;
							buildinfo[bnum].x = x * 100000;
							Double y = rs.getDouble(3);
							cafe[i].y = y;
							buildinfo[bnum].y = y * 100000;
							i++;
							bnum++;
						}

						stmt = (Statement) con.createStatement();
						sql = "select * from pc;";
						Pc[] pc = new Pc[100];
						i = 0;
						rs = stmt.executeQuery(sql);
						while (rs.next()) {
							pc[i] = new Pc();
							String name = rs.getString(1);
							byte[] b = name.getBytes("EUC-KR");
							name = new String(b, "euckr");
							pc[i].name = name;
							buildinfo[bnum].name = name;
							buildinfo[bnum].type = "PC";
							Double x = rs.getDouble(2);
							pc[i].x = x;
							buildinfo[bnum].x = x * 100000;
							Double y = rs.getDouble(3);
							pc[i].y = y;
							buildinfo[bnum].y = y * 100000;
							i++;
							bnum++;
						}

						stmt = (Statement) con.createStatement();
						sql = "select * from station;";
						Station[] station = new Station[100];
						i = 0;
						rs = stmt.executeQuery(sql);
						while (rs.next()) {
							station[i] = new Station();
							String name = rs.getString(1);
							byte[] b = name.getBytes("EUC-KR");
							name = new String(b, "euckr");
							station[i].name = name;
							buildinfo[bnum].name = name;
							buildinfo[bnum].type = "station";
							Double x = rs.getDouble(2);
							station[i].x = x;
							buildinfo[bnum].x = x * 100000;
							Double y = rs.getDouble(3);
							station[i].y = y;
							buildinfo[bnum].y = y * 100000;
							i++;
							bnum++;
						}
						buildinfo[130].name = "IT����";
						buildinfo[130].x = 0;
						buildinfo[130].y = 0;
						buildinfo[130].type = "University";

					} catch (SQLException e1) {
						e1.printStackTrace();
					}

					try {
						if (stmt != null && !stmt.isClosed())
							stmt.close();
						if (rs != null && !rs.isClosed())
							rs.close();
					} catch (SQLException e1) {
						e1.printStackTrace();
					}

					try {
						if (con != null && !con.isClosed())
							con.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Start() {
		setIconImage(Toolkit.getDefaultToolkit()
				.getImage(Start.class.getResource("/ladybug.png")));
		
		AudioPlayer MGP = AudioPlayer.player;
		AudioStream BGM;
		AudioData MD;

		ContinuousAudioDataStream loop = null;

		try {
			InputStream test = new FileInputStream("C:\\tree.WAV");
			BGM = new AudioStream(test);
			AudioPlayer.player.start(BGM);
		} catch (FileNotFoundException e) {
			System.out.print(e.toString());
		} catch (IOException error) {
			System.out.print(error.toString());
		}
		MGP.start(loop);
		setTitle("Play_Plan_Table");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		contentPane = new JPanel();
		contentPane.setBackground(mint);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton btnStart = new JButton("");
		btnStart.setIcon(new ImageIcon(Start.class.getResource("/start.jpg")));
		btnStart.setForeground(mint);
		btnStart.setBackground(Color.WHITE);
		btnStart.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 25));
		btnStart.setBounds(303, 371, 155, 63);
		contentPane.add(btnStart);

		JLabel lblWelcomeToXxx = new JLabel("Welcome to PPT");
		lblWelcomeToXxx.setForeground(Color.WHITE);
		lblWelcomeToXxx.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 90));
		lblWelcomeToXxx.setBounds(34, 70, 782, 182);
		contentPane.add(lblWelcomeToXxx);

		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(Start.class.getResource("/tree.jpg")));
		label.setBounds(608, 293, 174, 260);
		contentPane.add(label);

		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon(Start.class.getResource("/santa.jpg")));
		label_1.setBounds(269, 210, 246, 168);
		contentPane.add(label_1);

		btnStart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object obj = e.getSource();
				if ((JButton) obj == btnStart) {
					Play_Time start = new Play_Time();
					dispose();
					start.setVisible(true);
				}
			}
		});
	}
}
