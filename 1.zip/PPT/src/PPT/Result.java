package PPT;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.SwingConstants;
import javax.swing.ImageIcon;

public class Result extends JFrame {

	private JPanel contentPane;
	double[] ip;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Result frame = new Result();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Result() {
		String[] order = Order.getMsg().split("/");
		String[] type = new String[5];
		int[] index = new int[5];
		double[] distance = { 0 };
		double min = 5000000;
		String rest = Food_Result.building;
		int mealindex = -1;
		int i;
		for (i = 0; i < Integer.parseInt(order[1]); i++) {
			type[i] = order[i + 2];
		}
		for (i = 2; i < Integer.parseInt(order[1]) + 2; i++) {
			if (order[i].equals("Meal")) {
				mealindex = i - 2;
				break;
			}
		}
		Graph g = new Graph(130);
		for (i = 1; i <= 130; i++)
			for (int j = i + 1; j <= 130; j++)
				g.input(i, j, Math.sqrt(Math.pow(Start.buildinfo[i].x - Start.buildinfo[j].x, 2)
						+ Math.pow(Start.buildinfo[i].y - Start.buildinfo[j].y, 2)));

		if (mealindex != -1) {
			for (int j = 0; j < 130; j++) {
				if (Start.buildinfo[j].name.equals(Food_Result.building)) {
					index[mealindex] = j;
					break;
				}
			} // �Ĵ��� �ǹ� ��ȣ�� ã���ִ� �ڵ�
			distance = g.dijkstra(index[mealindex]); // �Ĵ� �������� ���ͽ�Ʈ�� ����
			for (i = 1; i < mealindex + 1; i++) {
				for (int j = 0; j < 130; j++) {
					if (Start.buildinfo[j].type.equals(type[mealindex - i])) {
						if (distance[j] < min) {
							index[mealindex - i] = j;
							min = distance[j];
						}
					}
				}
				distance = g.dijkstra(index[mealindex - i]);
				min = 50000000;
			} // �Ĵ� �������� �������� ���ͽ�Ʈ�� ���� ���Ѽ� �ǹ� ��ȣ�� ã�Ƴ�
			distance = g.dijkstra(index[mealindex]); // �Ĵ� �������� ���ͽ�Ʈ�� ����
			for (i = mealindex + 1; i < Integer.parseInt(order[1]); i++) {
				for (int j = 0; j < 130; j++) {
					if (Start.buildinfo[j].type.equals(type[i])) {
						if (distance[j] < min) {
							index[i] = j;
							min = distance[j];
						}
					}
				}
				distance = g.dijkstra(index[i]);
				min = 50000000;
			}
		} else {
			distance = g.dijkstra(130);
			for (i = 0; i < Integer.parseInt(order[1]); i++) {
				for (int j = 0; j < 130; j++) {
					if (Start.buildinfo[j].type.equals(type[i])) {
						if (distance[j] < min) {
							index[i] = j;
							min = distance[j];
						}
					}
				}
				distance = g.dijkstra(index[i]);
				min = 50000000;
			}
		}
		setTitle("Play Plan Table");
		setIconImage(Toolkit.getDefaultToolkit()
				.getImage(Start.class.getResource("/ladybug.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		contentPane = new JPanel();
		contentPane.setBackground(Start.mint);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		JLabel build_2 = new JLabel(Start.buildinfo[index[1]].name);
		build_2.setHorizontalAlignment(SwingConstants.CENTER);
		build_2.setBounds(161, 470, 156, 62);
		build_2.setForeground(Color.WHITE);
		build_2.setBorder(new LineBorder(Color.WHITE, 2));
		build_2.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 15));
		contentPane.add(build_2);

		JLabel node2 = new JLabel("");
		node2.setIcon(new ImageIcon(Result.class.getResource("/circle.jpg")));
		node2.setBounds(204, 330, 59, 62);
		contentPane.add(node2);

		JLabel column_2 = new JLabel("");
		column_2.setIcon(new ImageIcon(Result.class.getResource("/horizon_bar.png")));
		column_2.setBounds(225, 370, 19, 101);
		contentPane.add(column_2);

		JLabel lblYourWay = new JLabel("Your way!");
		lblYourWay.setBounds(232, 12, 363, 93);
		lblYourWay.setForeground(Color.WHITE);
		lblYourWay.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 69));
		contentPane.add(lblYourWay);

		JLabel node_1 = new JLabel("");
		node_1.setIcon(new ImageIcon(Result.class.getResource("/circle.jpg")));
		node_1.setBounds(46, 330, 59, 62);
		contentPane.add(node_1);

		JLabel build_1 = new JLabel(Start.buildinfo[index[0]].name);
		build_1.setHorizontalAlignment(SwingConstants.CENTER);
		build_1.setBounds(0, 169, 156, 62);
		build_1.setForeground(Color.WHITE);
		build_1.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 15));
		build_1.setBorder(new LineBorder(Color.WHITE, 2));
		contentPane.add(build_1);
		
		JLabel column_1 = new JLabel("");
		column_1.setIcon(new ImageIcon(Result.class.getResource("/horizon_bar.png")));
		column_1.setBounds(65, 230, 19, 101);
		contentPane.add(column_1);

		JLabel bar_1 = new JLabel("");
		bar_1.setIcon(new ImageIcon(Result.class.getResource("/bar.jpg")));
		bar_1.setBounds(95, 352, 147, 18);
		contentPane.add(bar_1);

		if (Integer.parseInt(order[1]) >= 3) {
			JLabel node_3 = new JLabel("");
			node_3.setIcon(new ImageIcon(Result.class.getResource("/circle.jpg")));
			node_3.setBounds(357, 330, 59, 63);
			contentPane.add(node_3);

			JLabel build_3 = new JLabel(Start.buildinfo[index[2]].name);
			build_3.setHorizontalAlignment(SwingConstants.CENTER);
			build_3.setBounds(305, 169, 156, 62);
			build_3.setBorder(new LineBorder(Color.WHITE, 2));
			build_3.setForeground(Color.WHITE);
			build_3.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 15));
			contentPane.add(build_3);

			JLabel bar_2 = new JLabel("");
			bar_2.setIcon(new ImageIcon(Result.class.getResource("/bar.jpg")));
			bar_2.setBounds(256, 352, 107, 18);
			contentPane.add(bar_2);

			JLabel column_3 = new JLabel("");
			column_3.setIcon(new ImageIcon(Result.class.getResource("/horizon_bar.png")));
			column_3.setBounds(376, 230, 19, 101);
			contentPane.add(column_3);

			if (Integer.parseInt(order[1]) >= 4) {
				JLabel node_4 = new JLabel("");
				node_4.setIcon(new ImageIcon(Result.class.getResource("/circle.jpg")));
				node_4.setBounds(520, 330, 53, 62);
				contentPane.add(node_4);

				JLabel build_4 = new JLabel(Start.buildinfo[index[3]].name);
				build_4.setHorizontalAlignment(SwingConstants.CENTER);
				build_4.setBounds(472, 470, 156, 62);
				build_4.setForeground(Color.WHITE);
				build_4.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 15));
				build_4.setBorder(new LineBorder(Color.WHITE, 2));
				contentPane.add(build_4);

				JLabel bar_3 = new JLabel("");
				bar_3.setIcon(new ImageIcon(Result.class.getResource("/bar.jpg")));
				bar_3.setBounds(409, 352, 147, 18);
				contentPane.add(bar_3);

				JLabel column_4 = new JLabel("");
				column_4.setIcon(new ImageIcon(Result.class.getResource("/horizon_bar.png")));
				column_4.setBounds(537, 370, 19, 101);
				contentPane.add(column_4);

				if (Integer.parseInt(order[1]) == 5) {
					JLabel node_5 = new JLabel("");
					node_5.setIcon(new ImageIcon(Result.class.getResource("/circle.jpg")));
					node_5.setBounds(685, 330, 53, 62);
					contentPane.add(node_5);

					JLabel build_5 = new JLabel(Start.buildinfo[index[4]].name);
					build_5.setHorizontalAlignment(SwingConstants.CENTER);
					build_5.setBounds(626, 169, 156, 62);
					build_5.setForeground(Color.WHITE);
					build_5.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 15));
					build_5.setBorder(new LineBorder(Color.WHITE, 2));
					contentPane.add(build_5);

					JLabel bar_4 = new JLabel("");
					bar_4.setIcon(new ImageIcon(Result.class.getResource("/bar.jpg")));
					bar_4.setBounds(570, 352, 147, 18);
					contentPane.add(bar_4);

					JLabel column_5 = new JLabel("");
					column_5.setIcon(new ImageIcon(Result.class.getResource("/horizon_bar.png")));
					column_5.setBounds(702, 230, 19, 101);
					contentPane.add(column_5);
				}
			}
		}
	}
}
