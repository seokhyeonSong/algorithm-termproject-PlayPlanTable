package PPT;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JButton;

public class Order extends JFrame {

	private JPanel contentPane;
	static int PCnum;
	static int Singnum;
	static int Drinknum;
	static int Mealnum;
	static int Cafenum;
	static int Pocketnum;
	static String max = "";
	static String mmax = "";
	static String msg = "";
	String[] order;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {

					Order frame = new Order();
					frame.setVisible(true);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	static String getMsg() {
		return msg;
	}

	static String Max() {
		int j = 0;
		for (int i = 1; i < 6; i++) {
			if (i == PCnum)
				mmax = "PC";
			else if (i == Singnum)
				mmax = "Sing";
			else if (i == Mealnum)
				mmax = "Meal";
			else if (i == Cafenum)
				mmax = "Cafe";
			else if (i == Pocketnum)
				mmax = "Pocket";
			else if (PCnum == -1) {
				mmax = "";
			} else if (Singnum == -1) {
				mmax = "";
			} else if (Mealnum == -1) {
				mmax = "";
			} else if (Cafenum == -1) {
				mmax = "";
			} else if (Pocketnum == -1) {
				mmax = "";
			}
			if (mmax == "") {
			} else {
				max = max + "/" + mmax;
				j++;
			}
		}
		return j + max;
	}

	public Order() {
		setTitle("Play_Plan_Table");

		setIconImage(Toolkit.getDefaultToolkit()
				.getImage(Start.class.getResource("/ladybug.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		contentPane = new JPanel();
		contentPane.setBackground(Start.mint);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel label = new JLabel("\uC21C\uC11C\uB97C \uC815\uD574\uC8FC\uC138\uC694\r\n");
		label.setForeground(Color.WHITE);
		label.setBackground(Color.GRAY);
		label.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.BOLD, 50));
		label.setBounds(207, 123, 398, 75);
		contentPane.add(label);

		JComboBox PC = new JComboBox();
		PC.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 15));
		PC.setBackground(Color.WHITE);
		PC.setModel(new DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "X" }));
		PC.setBounds(194, 264, 52, 24);
		contentPane.add(PC);

		JComboBox Sing = new JComboBox();
		Sing.setBackground(Color.WHITE);
		Sing.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 15));
		Sing.setModel(new DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "X" }));
		Sing.setBounds(194, 322, 52, 24);
		contentPane.add(Sing);

		JComboBox Meal = new JComboBox();
		Meal.setBackground(Color.WHITE);
		Meal.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 15));
		Meal.setModel(new DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "X" }));
		Meal.setBounds(194, 378, 52, 24);
		contentPane.add(Meal);

		JComboBox Cafe = new JComboBox();
		Cafe.setBackground(Color.WHITE);
		Cafe.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 15));
		Cafe.setModel(new DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "X" }));
		Cafe.setBounds(194, 432, 52, 24);
		contentPane.add(Cafe);

		JComboBox Pocket = new JComboBox();
		Pocket.setBackground(Color.WHITE);
		Pocket.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 15));
		Pocket.setModel(new DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "X" }));
		Pocket.setBounds(194, 486, 52, 24);
		contentPane.add(Pocket);

		JLabel label_1 = new JLabel("\uD53C\uC2DC\uBC29");
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.BOLD, 25));
		label_1.setBounds(108, 250, 72, 47);
		contentPane.add(label_1);

		JLabel label_2 = new JLabel("\uB178\uB798\uBC29");
		label_2.setForeground(Color.WHITE);
		label_2.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.BOLD, 25));
		label_2.setBounds(108, 309, 72, 44);
		contentPane.add(label_2);

		JLabel label_3 = new JLabel("\uBC25");
		label_3.setForeground(Color.WHITE);
		label_3.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.BOLD, 25));
		label_3.setBounds(149, 365, 30, 44);
		contentPane.add(label_3);

		JLabel label_5 = new JLabel("\uCE74\uD398");
		label_5.setForeground(Color.WHITE);
		label_5.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.BOLD, 25));
		label_5.setBounds(128, 419, 52, 44);
		contentPane.add(label_5);

		JLabel label_6 = new JLabel("\uB2F9\uAD6C");
		label_6.setForeground(Color.WHITE);
		label_6.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.BOLD, 25));
		label_6.setBounds(128, 472, 52, 47);
		contentPane.add(label_6);

		JButton next = new JButton("");
		next.setIcon(new ImageIcon(Order.class.getResource("/submit.jpg")));
		next.setBounds(371, 365, 130, 50);
		contentPane.add(next);

		JLabel label_4 = new JLabel("\uBC88\uC9F8");
		label_4.setForeground(Color.WHITE);
		label_4.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 20));
		label_4.setBounds(260, 267, 62, 18);
		contentPane.add(label_4);

		JLabel label_7 = new JLabel("\uBC88\uC9F8");
		label_7.setForeground(Color.WHITE);
		label_7.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 20));
		label_7.setBounds(260, 324, 62, 18);
		contentPane.add(label_7);

		JLabel label_8 = new JLabel("\uBC88\uC9F8");
		label_8.setForeground(Color.WHITE);
		label_8.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 20));
		label_8.setBounds(260, 380, 62, 18);
		contentPane.add(label_8);

		JLabel label_9 = new JLabel("\uBC88\uC9F8");
		label_9.setForeground(Color.WHITE);
		label_9.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 20));
		label_9.setBounds(260, 435, 62, 18);
		contentPane.add(label_9);

		JLabel label_10 = new JLabel("\uBC88\uC9F8");
		label_10.setForeground(Color.WHITE);
		label_10.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 20));
		label_10.setBounds(260, 489, 62, 18);
		contentPane.add(label_10);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(
				new ImageIcon("C:\\Users\\\uC1A1\uC11D\uD604\\Desktop\\\uC54C\uACE0\uC774\uBBF8\uC9C0\\treeside.png"));
		lblNewLabel.setBounds(0, -33, 367, 336);
		contentPane.add(lblNewLabel);

		JLabel label_11 = new JLabel("");
		label_11.setIcon(new ImageIcon(Order.class.getResource("/tree.jpg")));
		label_11.setBounds(602, 293, 180, 260);
		contentPane.add(label_11);
		next.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String PCs = PC.getSelectedItem().toString();
				String Sings = Sing.getSelectedItem().toString();
				String Cafes = Cafe.getSelectedItem().toString();
				String Pockets = Pocket.getSelectedItem().toString();
				String Meals = Meal.getSelectedItem().toString();
				if (PCs.equals(Sings) || PCs.equals(Cafes) || PCs.equals(Pockets) || PCs.equals(Meals)
						|| Sings.equals(Cafes) || Sings.equals(Pockets) || Sings.equals(Meals) || Cafes.equals(Pockets)
						|| Cafes.equals(Meals) || Pockets.equals(Meals)) {
					JOptionPane.showMessageDialog(null, "�ٸ� ������ ����ּ���.");
				} else {
					if (PC.getSelectedItem().toString() != "X") {
						PCnum = Integer.parseInt(PC.getSelectedItem().toString());
					} else
						PCnum = -1;
					if (Sing.getSelectedItem().toString() != "X") {
						Singnum = Integer.parseInt(Sing.getSelectedItem().toString());
					} else
						Singnum = -1;
					if (Meal.getSelectedItem().toString() != "X") {
						Mealnum = Integer.parseInt(Meal.getSelectedItem().toString());
					} else
						Mealnum = -1;
					if (Cafe.getSelectedItem().toString() != "X") {
						Cafenum = Integer.parseInt(Cafe.getSelectedItem().toString());
					} else
						Cafenum = -1;
					if (Pocket.getSelectedItem().toString() != "X") {
						Pocketnum = Integer.parseInt(Pocket.getSelectedItem().toString());
					} else
						Pocketnum = -1;
					Object obj = e.getSource();
					msg = Max();
					order = msg.split("/");
					if ((JButton) obj == next) {
						if (order[1].equals("PC")) {
							PC_Time time = new PC_Time();
							msg = "1/" + msg;
							dispose();
							time.setVisible(true);
						} else if (order[1].equals("Sing")) {
							Sing_Time time = new Sing_Time();
							msg = "1/" + msg;
							dispose();
							time.setVisible(true);
						} else if (order[1].equals("Pocket")) {
							Pocket_Time time = new Pocket_Time();
							msg = "1/" + msg;
							dispose();
							time.setVisible(true);
						} else if (order[1].equals("Meal")) {
							Food_Attr1 time = new Food_Attr1();
							msg = "1/" + msg;
							dispose();
							time.setVisible(true);
						} else if (order[1].equals("Cafe")) {
							Cafe_Time time = new Cafe_Time();
							msg = "1/" + msg;
							dispose();
							time.setVisible(true);
						}
					}
				}
			}
		});
	}

}
