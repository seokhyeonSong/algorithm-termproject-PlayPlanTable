package PPT;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.SwingConstants;

public class Sing_Time extends JFrame {
	String msg = "";
	String order[];
	private JPanel contentPane;
	private JTextField textField;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PC_Time frame = new PC_Time();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Sing_Time() {
		setTitle("Play Plan Table");
		setIconImage(Toolkit.getDefaultToolkit()
				.getImage(Start.class.getResource("/ladybug.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 601);
		contentPane = new JPanel();
		contentPane.setBackground(Start.mint);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblPc = new JLabel(
				"\uB178\uB798\uB97C \uBA87 \uACE1\uC774\uB098 \uBD80\uB97C \uC608\uC815\uC785\uB2C8\uAE4C?");
		lblPc.setForeground(Color.WHITE);
		lblPc.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 50));
		lblPc.setBounds(51, 201, 703, 90);
		contentPane.add(lblPc);

		textField = new JTextField();
		textField.setHorizontalAlignment(SwingConstants.RIGHT);
		textField.setBorder(new LineBorder(Color.WHITE, 2));
		textField.setForeground(Color.WHITE);
		textField.setBackground(Start.mint);
		textField.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 25));
		textField.setBounds(280, 324, 95, 40);
		contentPane.add(textField);
		textField.setColumns(10);

		JLabel label = new JLabel("\uACE1");
		label.setForeground(Color.WHITE);
		label.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 40));
		label.setBounds(403, 325, 62, 39);
		contentPane.add(label);
		JLabel lblNewLabel_2 = new JLabel(Integer.toString(Play_Time.left));
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(84, 13, 62, 18);
		contentPane.add(lblNewLabel_2);
		JButton btnNext = new JButton("");
		btnNext.setSelectedIcon(
				new ImageIcon(Pocket_Time.class.getResource("/com/sun/java/swing/plaf/motif/icons/untitled.png")));
		btnNext.setIcon(new ImageIcon(Sing_Time.class.getResource("/submit.jpg")));
		btnNext.setBounds(479, 314, 130, 50);
		contentPane.add(btnNext);
		JLabel label_1 = new JLabel("\uB0A8\uC740\uC2DC\uAC04");
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 20));
		label_1.setBounds(14, 12, 70, 18);
		contentPane.add(label_1);

		JLabel lblNewLabel = new JLabel("  \uBD84\r\n");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 20));
		lblNewLabel.setBounds(98, 12, 62, 18);
		contentPane.add(lblNewLabel);
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object obj = e.getSource();
				if ((JButton) obj == btnNext) {
					msg = Order.getMsg();
					Play_Time.left = Play_Time.left - Integer.parseInt(textField.getText().toString()) * 4;
					order = msg.split("/");
					if (order[0].equals(order[1])) {
						Result re = new Result();
						dispose();
						re.setVisible(true);
					} else {
						if (order[0].equals("1")) {
							if (order[3].equals("PC")) {
								PC_Time time = new PC_Time();
								Order.msg = "2/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[3].equals("Sing")) {
								Sing_Time time = new Sing_Time();
								Order.msg = "2/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[3].equals("Pocket")) {
								Pocket_Time time = new Pocket_Time();
								Order.msg = "2/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[3].equals("Meal")) {
								Food_Attr1 time = new Food_Attr1();
								Order.msg = "2/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[3].equals("Cafe")) {
								Cafe_Time time = new Cafe_Time();
								Order.msg = "2/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							}
						} else if (order[0].equals("2")) {
							if (order[4].equals("PC")) {
								PC_Time time = new PC_Time();
								Order.msg = "3/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[4].equals("Sing")) {
								Sing_Time time = new Sing_Time();
								Order.msg = "3/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[4].equals("Pocket")) {
								Pocket_Time time = new Pocket_Time();
								Order.msg = "3/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[4].equals("Meal")) {
								Food_Attr1 time = new Food_Attr1();
								Order.msg = "3/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[4].equals("Cafe")) {
								Cafe_Time time = new Cafe_Time();
								Order.msg = "3/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							}
						} else if (order[0].equals("3")) {
							if (order[5].equals("PC")) {
								PC_Time time = new PC_Time();
								Order.msg = "4/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[5].equals("Sing")) {
								Sing_Time time = new Sing_Time();
								Order.msg = "4/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[5].equals("Pocket")) {
								Pocket_Time time = new Pocket_Time();
								Order.msg = "4/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[5].equals("Meal")) {
								Food_Attr1 time = new Food_Attr1();
								Order.msg = "4/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[5].equals("Cafe")) {
								Cafe_Time time = new Cafe_Time();
								Order.msg = "4/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							}
						} else if (order[0].equals("4")) {
							if (order[6].equals("PC")) {
								PC_Time time = new PC_Time();
								Order.msg = "5/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[6].equals("Sing")) {
								Sing_Time time = new Sing_Time();
								Order.msg = "5/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[6].equals("Pocket")) {
								Pocket_Time time = new Pocket_Time();
								Order.msg = "5/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[6].equals("Meal")) {
								Food_Attr1 time = new Food_Attr1();
								Order.msg = "5/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							} else if (order[6].equals("Cafe")) {
								Cafe_Time time = new Cafe_Time();
								Order.msg = "5/" + msg.substring(2);
								dispose();
								time.setVisible(true);
							}

						}
					}
				}
			}
		});

	}
}
