package PPT;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.JButton;
import javax.swing.ImageIcon;

public class Food_Attr2 extends JFrame {

	private JPanel contentPane;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Food_Attr2 frame = new Food_Attr2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Food_Attr2() {
		setTitle("Play_Plan_Table");

		setIconImage(Toolkit.getDefaultToolkit()
				.getImage(Start.class.getResource("/ladybug.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		contentPane = new JPanel();
		contentPane.setBackground(Start.mint);
		contentPane.setForeground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel_3 = new JLabel("  \uBD84");
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 19));
		lblNewLabel_3.setBounds(100, 12, 62, 18);
		contentPane.add(lblNewLabel_3);

		JLabel lblNewLabel_2 = new JLabel(Integer.toString(Play_Time.left));
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(83, 12, 62, 18);
		contentPane.add(lblNewLabel_2);

		JLabel label_1 = new JLabel("\uB0A8\uC740\uC2DC\uAC04");
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 19));
		label_1.setBounds(14, 12, 62, 18);
		contentPane.add(label_1);

		JLabel lblF = new JLabel("\uB2E4\uC74C \uC74C\uC2DD\uB9DB\uC740 \uC5B4\uB5A4\uAC00\uC694?");
		lblF.setForeground(Color.WHITE);
		lblF.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 55));
		lblF.setBounds(117, 163, 552, 96);
		contentPane.add(lblF);

		JLabel lblNewLabel = new JLabel("�߰ſ� ����");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 30));
		lblNewLabel.setBounds(161, 309, 140, 39);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("���� ����");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 30));
		lblNewLabel_1.setBounds(161, 403, 109, 39);
		contentPane.add(lblNewLabel_1);

		JComboBox hot = new JComboBox();
		hot.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 20));
		hot.setModel(new DefaultComboBoxModel(new String[] { "���ƿ�", "�Ⱦ��" }));
		hot.setSelectedIndex(1);
		hot.setMaximumRowCount(5);
		hot.setBounds(307, 313, 147, 35);
		contentPane.add(hot);

		JComboBox soup = new JComboBox();
		soup.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 20));
		soup.setModel(new DefaultComboBoxModel(new String[] { "���ƿ�", "�Ⱦ��" }));
		soup.setMaximumRowCount(3);
		soup.setBounds(307, 403, 147, 35);
		contentPane.add(soup);

		JButton btnNext = new JButton("");
		btnNext.setBorder(new EmptyBorder(5, 5, 5, 5));
		btnNext.setIcon(new ImageIcon(Food_Attr2.class.getResource("/next.png")));
		btnNext.setBounds(501, 335, 91, 79);
		contentPane.add(btnNext);
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object obj = e.getSource();
				if (hot.getSelectedItem().toString().equals("���ƿ�"))
					Food_Attr1.LCS.add(1);
				else
					Food_Attr1.LCS.add(0);
				if (soup.getSelectedItem().toString().equals("���ƿ�"))
					Food_Attr1.LCS.add(1);
				else
					Food_Attr1.LCS.add(0);

				if ((JButton) obj == btnNext) {
					Food_Attr3 food = new Food_Attr3();
					dispose();
					food.setVisible(true);
				}
			}
		});
	}
}
