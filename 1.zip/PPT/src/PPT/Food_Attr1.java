package PPT;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.Color;
import javax.swing.ImageIcon;

public class Food_Attr1 extends JFrame {

	private JPanel contentPane;
	static ArrayList<Integer> LCS = new ArrayList();
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Food_Attr1 frame = new Food_Attr1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public Food_Attr1() {
		setTitle("Play_Plan_Table");

		setIconImage(Toolkit.getDefaultToolkit()
				.getImage(Start.class.getResource("/ladybug.png")));
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		contentPane = new JPanel();
		contentPane.setBackground(Start.mint);
		contentPane.setForeground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("  \uBD84");
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 19));
		lblNewLabel_3.setBounds(100, 12, 62, 18);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_2 = new JLabel(Integer.toString(Play_Time.left));
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(83, 12, 62, 18);
		contentPane.add(lblNewLabel_2);
		
		JLabel label_1 = new JLabel("\uB0A8\uC740\uC2DC\uAC04");
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 19));
		label_1.setBounds(14, 12, 62, 18);
		contentPane.add(label_1);
		
		JLabel lblF = new JLabel("\uB2E4\uC74C \uC74C\uC2DD\uB9DB\uC740 \uC5B4\uB5A4\uAC00\uC694?");
		lblF.setForeground(Color.WHITE);
		lblF.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 55));
		lblF.setBounds(117, 163, 552, 96);
		contentPane.add(lblF);
		
		JLabel lblNewLabel = new JLabel("\uB9E4\uC6B4 \uC74C\uC2DD\r\n");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 30));
		lblNewLabel.setBounds(158, 307, 400, 39);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\uB2E8 \uC74C\uC2DD");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 30));
		lblNewLabel_1.setBounds(162, 403, 109, 39);
		contentPane.add(lblNewLabel_1);
		
		
		
		JButton btnNext = new JButton("");
		btnNext.setBorder(new EmptyBorder(5,5,5,5));
		btnNext.setIcon(new ImageIcon(Food_Attr1.class.getResource("/next.png")));
		btnNext.setBounds(501, 335, 91, 79);
		contentPane.add(btnNext);
	
		JComboBox spicy = new JComboBox();
		spicy.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 19));
		spicy.setForeground(Color.BLACK);
		spicy.setBackground(SystemColor.text);
		spicy.setModel(new DefaultComboBoxModel(new String[] {"���ƿ�", "�����ƿ�", "������ �ʾƿ�", "���ο���"}));
		spicy.setSelectedIndex(1);
		spicy.setMaximumRowCount(4);
		spicy.setBounds(311, 312, 148, 35);
		contentPane.add(spicy);
		
		JComboBox sweet = new JComboBox();
		sweet.setForeground(Color.BLACK);
		sweet.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 19));
		sweet.setModel(new DefaultComboBoxModel(new String[] {"���ƿ�", "�����ƿ�", "������ �ʾƿ�", "���ο���"}));
		sweet.setMaximumRowCount(5);
		sweet.setBounds(311, 403, 148, 35);
		contentPane.add(sweet);
		btnNext.addActionListener(new ActionListener() {
	          public void actionPerformed(ActionEvent e) {
	             Object obj = e.getSource();
	             if(spicy.getSelectedItem().toString().equals("���ƿ�"))
					LCS.add(4);
	             else if(spicy.getSelectedItem().toString().equals("�����ƿ�"))
	            	 LCS.add(3);
	             else if(spicy.getSelectedItem().toString().equals("������ �ʾƿ�"))
	            	 LCS.add(2);
	             else if(spicy.getSelectedItem().toString().equals("���ο���"))
	            	 LCS.add(1);
	             if(sweet.getSelectedItem().toString().equals("���ƿ�"))
						LCS.add(4);
		         else if(sweet.getSelectedItem().toString().equals("�����ƿ�"))
		            	 LCS.add(3);
		         else if(sweet.getSelectedItem().toString().equals("������ �ʾƿ�"))
		            	 LCS.add(2);
		         else if(sweet.getSelectedItem().toString().equals("���ο���"))
		            	 LCS.add(1);
	             if ((JButton) obj == btnNext) {
	            	 Food_Attr2 food = new Food_Attr2();
     	 			dispose();
     	 			food.setVisible(true);
		         }
	       }
	   });
	}
}
