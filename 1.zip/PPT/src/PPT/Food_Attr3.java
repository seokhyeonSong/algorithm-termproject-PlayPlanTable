package PPT;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Food_Attr3 extends JFrame {

	private JPanel contentPane;
	String msg = "";
	String order[];

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DB test = new DB();
					Food_Attr3 frame = new Food_Attr3();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Food_Attr3() {
		setTitle("Play_Plan_Table");
		setIconImage(Toolkit.getDefaultToolkit()
				.getImage(Start.class.getResource("/ladybug.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		contentPane = new JPanel();
		contentPane.setBackground(Start.mint);
		contentPane.setForeground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel_3 = new JLabel("  \uBD84");
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 19));
		lblNewLabel_3.setBounds(100, 12, 62, 18);
		contentPane.add(lblNewLabel_3);

		JLabel lblNewLabel_2 = new JLabel(Integer.toString(Play_Time.left));
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(83, 12, 27, 18);
		contentPane.add(lblNewLabel_2);

		JLabel label_1 = new JLabel("\uB0A8\uC740\uC2DC\uAC04");
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 19));
		label_1.setBounds(14, 12, 62, 18);
		contentPane.add(label_1);

		JLabel lblF = new JLabel("\uB2E4\uC74C \uC74C\uC2DD\uB9DB\uC740 \uC5B4\uB5A4\uAC00\uC694?");
		lblF.setForeground(Color.WHITE);
		lblF.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 55));
		lblF.setBounds(117, 163, 552, 96);
		contentPane.add(lblF);

		JLabel lblNewLabel = new JLabel("���� ����");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 30));
		lblNewLabel.setBounds(161, 309, 111, 39);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("�⸧�� ����");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 30));
		lblNewLabel_1.setBounds(161, 403, 142, 39);
		contentPane.add(lblNewLabel_1);

		JComboBox type = new JComboBox();
		type.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 20));
		type.setModel(new DefaultComboBoxModel(new String[] { "��", "��", "��Ÿ" }));
		type.setMaximumRowCount(5);
		type.setBounds(317, 309, 148, 35);
		contentPane.add(type);

		JComboBox oil = new JComboBox();
		oil.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 20));
		oil.setModel(new DefaultComboBoxModel(new String[] { "���ƿ�", "�����ƿ�", "������ �ʾƿ�", "���ο���" }));
		oil.setMaximumRowCount(3);
		oil.setBounds(317, 409, 148, 35);
		contentPane.add(oil);

		JButton btnNext = new JButton("");
		btnNext.setBorder(new EmptyBorder(5, 5, 5, 5));
		btnNext.setIcon(new ImageIcon(Food_Attr3.class.getResource("/next.png")));
		btnNext.setBounds(501, 335, 91, 79);
		contentPane.add(btnNext);
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object obj = e.getSource();
				Play_Time.left = Play_Time.left - 30;
				if (type.getSelectedItem().toString().equals("��"))
					Food_Attr1.LCS.add(2);
				else if (type.getSelectedItem().toString().equals("��"))
					Food_Attr1.LCS.add(1);
				else if (type.getSelectedItem().toString().equals("��Ÿ"))
					Food_Attr1.LCS.add(3);
				if (oil.getSelectedItem().toString().equals("���ƿ�"))
					Food_Attr1.LCS.add(4);
				else if (oil.getSelectedItem().toString().equals("�����ƿ�"))
					Food_Attr1.LCS.add(3);
				else if (oil.getSelectedItem().toString().equals("������ �ʾƿ�"))
					Food_Attr1.LCS.add(2);
				else if (oil.getSelectedItem().toString().equals("���ο���"))
					Food_Attr1.LCS.add(1);
				if ((JButton) obj == btnNext) {
					Food_Result food = new Food_Result();
					dispose();
					food.setVisible(true);
				}
			}
		});
	}

}
