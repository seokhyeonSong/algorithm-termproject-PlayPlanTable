package PPT;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

public class Play_Time extends JFrame {

	JPanel contentPane;
	static JTextField leftTime;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Play_Time frame = new Play_Time();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	static int left;

	static int get_time() {

		return left;
	}

	public Play_Time() {
		setTitle("Play_Plan_Table");

		setIconImage(Toolkit.getDefaultToolkit()
				.getImage(Start.class.getResource("/ladybug.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		contentPane = new JPanel();
		contentPane.setBackground(Start.mint);
		setContentPane(contentPane);
		contentPane.setLayout(null);

		leftTime = new JTextField();
		leftTime.setBorder(new LineBorder(Color.WHITE, 2));
		leftTime.setHorizontalAlignment(SwingConstants.RIGHT);
		leftTime.setForeground(Color.WHITE);
		leftTime.setBackground(Start.mint);
		leftTime.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 30));
		leftTime.setBounds(264, 304, 159, 39);
		contentPane.add(leftTime);
		leftTime.setColumns(10);

		JButton select = new JButton("");
		select.setIcon(new ImageIcon(Play_Time.class.getResource("/submit.jpg")));
		select.setBounds(505, 293, 130, 50);
		contentPane.add(select);

		JLabel label = new JLabel("\uB2F9\uC2E0\uC758 \uB180 \uC2DC\uAC04\uC744 \uC785\uB825\uD558\uC138\uC694");
		label.setForeground(Color.WHITE);
		label.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 50));
		label.setBounds(105, 162, 569, 70);
		contentPane.add(label);

		JLabel label_1 = new JLabel("\uBD84");
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("����ǹ��� �ѳ�ü Pro", Font.PLAIN, 30));
		label_1.setBounds(437, 304, 33, 32);
		contentPane.add(label_1);

		select.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object obj = e.getSource();
				if ((JButton) obj == select) {
					left = Integer.parseInt(leftTime.getText().toString());
					Order what = new Order();
					dispose();
					what.setVisible(true);
				}
			}
		});
	}

}
